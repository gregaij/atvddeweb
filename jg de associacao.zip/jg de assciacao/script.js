const associations = [  
    { term: "Sopro", definition: "Flauta" },  
    { term: "Cordas", definition: "Guitarra" },  
    { term: "Teclado", definition: "Piano" },  
    { term: "Arco", definition: "Violino" }  
];  

let shuffledTerms = []; // Array para armazenar termos embaralhados  
let shuffledDefinitions = []; // Array para armazenar definições embaralhadas  
let selectedTerm = null;  
let selectedDefinition = null;  
let correctAnswersCount = 0; // Contador de respostas corretas  
const totalPairs = associations.length; // Total de pares a serem encontrados  

// Função para embaralhar um array  
function shuffleArray(array) {  
    for (let i = array.length - 1; i > 0; i--) {  
        const j = Math.floor(Math.random() * (i + 1));  
        [array[i], array[j]] = [array[j], array[i]]; // Troca os elementos  
    }  
}  

// Inicializa o jogo  
function initializeGame() {  
    shuffleArray(associations); // Embaralha as associações  
    shuffledTerms = associations.map(item => item.term);  
    shuffledDefinitions = associations.map(item => item.definition);  
    displayTerms();  
    displayDefinitions();  
    correctAnswersCount = 0; // Reinicia o contador de respostas corretas
    document.getElementById('result').textContent = ''; // Limpa o resultado anterior
    document.getElementById('winnerMessage').style.display = 'none'; // Esconde a mensagem de vencedor
    document.getElementById('checkAnswers').style.display = 'block'; // Mostra o botão de verificar respostas
    document.getElementById('backHome').style.display = 'none'; // Esconde o botão de voltar
}  

function displayTerms() {  
    const termsContainer = document.getElementById('terms');  
    termsContainer.innerHTML = ''; // LIMPAR CONTEÚDOS ANTERIORES  

    shuffledTerms.forEach((term, index) => {  
        const termElement = document.createElement('div');  
        termElement.classList.add('term');  
        termElement.textContent = term;  
        termElement.onclick = () => chooseTerm(index);  
        termsContainer.appendChild(termElement);  
    });  
}  

function displayDefinitions() {  
    const definitionsContainer = document.getElementById('definitions');  
    definitionsContainer.innerHTML = ''; // LIMPAR CONTEÚDOS ANTERIORES  

    shuffleArray(shuffledDefinitions); // Embaralhar apenas as definições  

    shuffledDefinitions.forEach((definition, index) => {  
        const definitionElement = document.createElement('div');  
        definitionElement.classList.add('definition');  
        definitionElement.textContent = definition;  
        definitionElement.onclick = () => chooseDefinition(index);  
        definitionsContainer.appendChild(definitionElement);  
    });  
}  

function chooseTerm(index) {  
    const termElements = document.querySelectorAll('.term');  
    termElements.forEach(element => element.classList.remove('selected'));  
    termElements[index].classList.add('selected');  
    selectedTerm = index; // Salva o índice do termo selecionado  
    clearSelection('definition'); // Limpa seleções anteriores de definições  
}  

function chooseDefinition(index) {  
    const definitionElements = document.querySelectorAll('.definition');  
    definitionElements.forEach(element => element.classList.remove('selected'));  
    definitionElements[index].classList.add('selected');  
    selectedDefinition = index; // Salva o índice da definição selecionada  
}  

function checkAnswers() {  
    const result = document.getElementById('result');  

    if (selectedTerm === null || selectedDefinition === null) {  
        result.textContent = "Por favor, selecione um termo e uma definição.";  
        return;  
    }  

    // Verifica a associação correta no array original  
    const correctDefinition = associations[selectedTerm].definition;  
    const selectedDefinitionText = shuffledDefinitions[selectedDefinition]; // Pegar a definição correspondente ao índice embaralhado  

    if (selectedDefinitionText === correctDefinition) {  
        result.textContent = "Correto!";  
        hideCorrectPair(selectedTerm, selectedDefinition); // Oculta os pares corretos  
        correctAnswersCount++; // Aumenta o contador de respostas corretas  
        checkIfGameCompleted(); // Verifica se o jogo foi completado  
    } else {  
        result.textContent = "Errado! Tente novamente.";  
    }  

    // Reset seleções  
    selectedTerm = null;  
    selectedDefinition = null;  
    clearSelection('term');  
    clearSelection('definition');  
}  

function hideCorrectPair(termIndex, definitionIndex) {  
    const termElements = document.querySelectorAll('.term');  
    const definitionElements = document.querySelectorAll('.definition');  

    // Oculta os elementos corretos  
    termElements[termIndex].style.display = 'none';  
    definitionElements[definitionIndex].style.display = 'none';  
}  

function clearSelection(type) {  
    const elements = document.querySelectorAll(`.${type}`);  
    elements.forEach(element => element.classList.remove('selected'));  
}  

function checkIfGameCompleted() {  
    if (correctAnswersCount === totalPairs) {  
        // Exibe mensagem de vencedor  
        const winnerMessage = document.getElementById('winnerMessage');  
        winnerMessage.textContent = "Aêê você venceu! Parabéns! ⭐ ";  
        winnerMessage.style.display = "block"; // Mostra a mensagem  
        document.getElementById('backHome').style.display = "block"; // Mostra o botão de voltar  
        document.getElementById('checkAnswers').style.display = "none"; // Esconde o botão de verificar respostas
    }  
}  

// Função para mostrar a página do jogo
function showGamePage() {
    document.getElementById('home').style.display = 'none';
    document.getElementById('game').style.display = 'block';
    initializeGame(); // Inicializa o jogo ao mostrar a página do jogo
}

// Função para voltar à página inicial
function showHomePage() {
    document.getElementById('home').style.display = 'block';
    document.getElementById('game').style.display = 'none';
}

// Inicializa o jogo
document.getElementById('startGame').onclick = showGamePage;
document.getElementById('backHome').onclick = showHomePage;
document.getElementById('checkAnswers').onclick = checkAnswers;
